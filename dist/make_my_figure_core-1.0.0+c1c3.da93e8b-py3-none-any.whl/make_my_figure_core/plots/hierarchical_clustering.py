"""Hierarchical clustering result view (v0.5).

A dedicated clustering *result* plot: cluster a features x samples matrix into
``k`` clusters, show the (scaled) matrix ordered by the dendrogram with a
cluster color strip on the clustered axis, and export the full cluster-assignment
table + summary in the render metadata (so the app can save the assignments as a
table). Distinct from the clustered heatmap (exploratory display) and the
standalone dendrogram (tree only).

Clustering is an exploratory summary — verify the chosen distance metric,
linkage, scaling, and k are appropriate for your data before interpreting.
"""

from __future__ import annotations

from typing import Any, Dict, List

import matplotlib.pyplot as plt
import numpy as np

from make_my_figure_core import clustering as _clust
from make_my_figure_core.plots._v04_shared import numeric_matrix
from make_my_figure_core.plots.base import (
    RenderError,
    RenderResult,
    base_metadata,
    get_mapping,
)
from make_my_figure_core.styles.engine import StyleProfile

PLOT_TYPE = "hierarchical_clustering"


def _draw_cluster_strip(ax, side: str, codes: np.ndarray, colors: List[str], style):
    from matplotlib.colors import ListedColormap
    from mpl_toolkits.axes_grid1 import make_axes_locatable

    cmap = ListedColormap(colors)
    divider = make_axes_locatable(ax)
    if side == "left":
        cax = divider.append_axes("left", size="4.5%", pad=0.06)
        cax.imshow(codes.reshape(-1, 1), aspect="auto", cmap=cmap, interpolation="nearest",
                   vmin=0, vmax=max(1, len(colors) - 1))
    else:
        cax = divider.append_axes("top", size="4.5%", pad=0.06)
        cax.imshow(codes.reshape(1, -1), aspect="auto", cmap=cmap, interpolation="nearest",
                   vmin=0, vmax=max(1, len(colors) - 1))
    # No axis label on the strip — it collided with the main x/y label; the legend
    # ("k clusters") identifies the colours instead.
    cax.set_xticks([]); cax.set_yticks([])
    cax._colorbar = True
    for spine in cax.spines.values():
        spine.set_visible(False)
    return cax


def _draw_dendrogram(ax, z, side: str, style, size: str = "15%"):
    """Append a monochrome dendrogram tree on the clustered side, aligned to the
    heatmap leaf order (a seaborn-style clustermap layout)."""
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    from scipy.cluster.hierarchy import dendrogram

    divider = make_axes_locatable(ax)
    orient = "left" if side == "left" else "top"
    dax = divider.append_axes(orient, size=size, pad=0.04)
    line_c = getattr(style, "text_color", "#333333")
    dendrogram(z, orientation=orient, ax=dax, no_labels=True,
               link_color_func=lambda _k: line_c)
    dax.set_xticks([]); dax.set_yticks([])
    for spine in dax.spines.values():
        spine.set_visible(False)
    # imshow puts row 0 at the TOP; a left dendrogram lists leaves bottom-up, so
    # flip it to keep the tree aligned with the heatmap rows.
    if side == "left":
        dax.invert_yaxis()
    dax._colorbar = True
    return dax


def render(spec: Dict[str, Any], df, style: StyleProfile) -> RenderResult:
    row_id = get_mapping(spec, "row_id", None)
    axis = str(get_mapping(spec, "cluster", "rows")).lower()
    if axis not in ("rows", "columns"):
        axis = "rows"
    k = int(get_mapping(spec, "k", 3))
    scale = str(get_mapping(spec, "scale", "row_zscore"))
    metric = str(get_mapping(spec, "distance_metric", "euclidean"))
    method = str(get_mapping(spec, "linkage_method", "average"))
    prefix = str(get_mapping(spec, "cluster_prefix", "Cluster"))
    exclude = get_mapping(spec, "exclude_columns", None)
    value_columns = get_mapping(spec, "value_columns", None)
    show_cluster_title = bool(get_mapping(spec, "cluster_legend_title", False))
    show_dendrogram = bool(get_mapping(spec, "show_dendrogram", False))
    y_label_rotation = str(get_mapping(spec, "y_label_rotation", "vertical")).lower()
    max_features = int(get_mapping(spec, "max_features", _clust.DEFAULT_MAX_CLUSTER_FEATURES))

    row_labels, value_cols, raw_matrix, warnings = numeric_matrix(
        df, row_id, context=PLOT_TYPE, exclude=exclude, value_columns=value_columns)
    # Memory guard: cap the feature (row) axis before the O(n^2) clustering when
    # clustering rows, so a huge matrix (e.g. 55k genes) can't exhaust RAM.
    if axis == "rows":
        raw_matrix, row_labels, _cap = _clust.cap_rows_by_variance(
            raw_matrix, row_labels, max_features, warnings)
    matrix, scale_warns = _clust.scale_matrix(raw_matrix, scale)
    warnings.extend(scale_warns)
    filled = np.nan_to_num(matrix, nan=0.0)

    # Cluster the chosen axis (this drives assignment + color strip).
    n_objects = raw_matrix.shape[0] if axis == "rows" else raw_matrix.shape[1]
    obj_labels = row_labels if axis == "rows" else list(value_cols)
    try:
        z = _clust.compute_linkage(filled, method=method, metric=metric, axis=axis)
        order = _clust.leaf_order(z)
        cluster_ids = _clust.cut_k(z, k, n_objects)
    except _clust.ClusteringError as exc:
        raise RenderError(f"{PLOT_TYPE}: {exc}") from exc

    # Order the OTHER axis by its own clustering (best-effort, for a clean map).
    other_axis = "columns" if axis == "rows" else "rows"
    n_other = raw_matrix.shape[1] if axis == "rows" else raw_matrix.shape[0]
    other_order = list(range(n_other))
    if n_other > 2:
        try:
            zo = _clust.compute_linkage(filled, method=method,
                                        metric=("euclidean" if method == "ward" else metric),
                                        axis=other_axis)
            other_order = _clust.leaf_order(zo)
        except Exception:
            pass

    if axis == "rows":
        row_order, col_order = order, other_order
    else:
        row_order, col_order = other_order, order

    ordered = matrix[np.ix_(row_order, col_order)]
    ordered_rows = [row_labels[i] for i in row_order]
    ordered_cols = [value_cols[j] for j in col_order]

    color_map = _clust.cluster_color_map(cluster_ids, prefix)
    ordered_labels = sorted(color_map.keys(), key=lambda s: int(s.split()[-1]))
    idx_of = {lab: i for i, lab in enumerate(ordered_labels)}
    colors = [color_map[lab] for lab in ordered_labels]
    codes = np.array([idx_of[f"{prefix} {int(cluster_ids[o])}"] for o in order])

    values_for_table = np.nanmean(raw_matrix, axis=1) if axis == "rows" else None
    table = _clust.assignment_table(
        obj_labels, cluster_ids, order, prefix=prefix,
        id_name=("feature" if axis == "rows" else "sample"),
        values=values_for_table)
    summary = _clust.cluster_summary(cluster_ids, method=method, metric=metric, scale=scale,
                                     k=k, axis=axis, warnings=warnings)

    vmax = np.nanmax(np.abs(matrix)) if np.isfinite(matrix).any() else 1.0
    diverging = scale in ("row_zscore", "column_zscore", "center_rows")
    cmap = style.diverging_cmap if diverging else style.sequential_cmap
    _explicit_cmap = get_mapping(spec, "colormap", None)
    if _explicit_cmap and str(_explicit_cmap).lower() not in ("", "auto"):
        cmap = str(_explicit_cmap)   # explicit publication colormap override
    if diverging:
        vmin, vmax = -vmax, vmax
    else:
        vmin = float(np.nanmin(matrix)) if np.isfinite(matrix).any() else 0.0
        vmax = float(np.nanmax(matrix)) if np.isfinite(matrix).any() else 1.0

    w_in, _ = style.figure_size_inches(str((spec.get("layout") or {}).get("column_width", "default")),
                                       aspect=1.0)
    n_r, n_c = len(ordered_rows), len(ordered_cols)
    # Height: when per-row labels are hidden (many features), the rows are dense
    # colour bands, so keep a COMPACT, display-friendly block (a tall strip is
    # unreadable on screen). Only grow tall when row labels are actually shown.
    if n_r > 60:
        h_in = w_in * 1.2                              # compact block; all rows as bands
    elif n_r > 12:
        h_in = min(1.8 + 0.16 * n_r, 12.0)             # room for the visible row labels
    else:
        h_in = w_in * 0.9
    with style.apply():
        fig, ax = plt.subplots(figsize=(w_in, h_in))
        im = ax.imshow(ordered, aspect="auto", cmap=cmap, vmin=vmin, vmax=vmax,
                       interpolation="nearest")
        strip_ax = _draw_cluster_strip(ax, "left" if axis == "rows" else "top",
                                       codes, colors, style)
        # Optional dendrogram tree, appended OUTSIDE the colour strip (so the layout
        # reads [tree][cluster strip][heatmap]) and aligned to the heatmap leaves.
        if show_dendrogram:
            _draw_dendrogram(ax, z, "left" if axis == "rows" else "top", style)

        row_fs = style.tick_label_pt if n_r <= 25 else (0.0 if n_r > 60 else max(6.0, style.tick_label_pt - 3))
        col_fs = style.tick_label_pt if n_c <= 25 else (0.0 if n_c > 60 else max(6.0, style.tick_label_pt - 3))
        # Explicit font-size + show/hide controls (parity with the clustered heatmap).
        _rlf = get_mapping(spec, "row_label_fontsize", None)
        if _rlf:
            row_fs = float(_rlf)
        _clf = get_mapping(spec, "col_label_fontsize", None)
        if _clf:
            col_fs = float(_clf)
        if get_mapping(spec, "show_row_labels", None) is False:
            row_fs = 0.0
        # With a LEFT cluster strip (row clustering), put the row labels + y-label on
        # the RIGHT so the strip on the left is never overlapped/buried (seaborn-style).
        labels_right = (axis == "rows")
        if row_fs > 0:
            ax.set_yticks(range(n_r)); ax.set_yticklabels(ordered_rows, fontsize=row_fs)
        else:
            ax.set_yticks([])
        if labels_right:
            ax.yaxis.tick_right()
        if col_fs > 0:
            ax.set_xticks(range(n_c)); ax.set_xticklabels(ordered_cols, rotation=90, fontsize=col_fs)
        else:
            ax.set_xticks([])
        ax.set_xlabel((spec.get("layout") or {}).get("x_label", "Sample"))
        y_label = (spec.get("layout") or {}).get("y_label", str(row_id or df.columns[0]))
        if labels_right:
            ax.yaxis.set_label_position("right")
        _yrot = 0 if y_label_rotation in ("horizontal", "0") else 90
        ax.set_ylabel(y_label, rotation=_yrot, ha=("left" if _yrot == 0 else "center"),
                      va="center")
        _lay = spec.get("layout") or {}
        ax.yaxis.labelpad = float(get_mapping(spec, "y_label_pad", _lay.get("y_label_pad", 6.0)) or 6.0)
        title = _lay.get("title")
        if title:
            fig.suptitle(title, fontsize=style.title_font_pt, fontweight="bold")
        # Colorbar placement + size are configurable; default gap is larger when the
        # row labels sit on the right so the z-score bar clears them.
        _auto_pad = (0.16 if row_fs > 0 else 0.06) if labels_right else 0.03
        cb_loc = str(get_mapping(spec, "colorbar_location", _lay.get("colorbar_location", "right"))).lower()
        if cb_loc not in ("right", "left", "top", "bottom"):
            cb_loc = "right"
        cb_pad = float(get_mapping(spec, "colorbar_pad", _lay.get("colorbar_pad", _auto_pad)) or _auto_pad)
        cb_frac = float(get_mapping(spec, "colorbar_fraction", _lay.get("colorbar_fraction", 0.045)) or 0.045)
        cb_shrink = float(get_mapping(spec, "colorbar_shrink", _lay.get("colorbar_shrink", 1.0)) or 1.0)
        cbar = fig.colorbar(im, ax=ax, location=cb_loc, fraction=cb_frac, pad=cb_pad, shrink=cb_shrink)
        cbar.set_label(_lay.get("colorbar_label",
                       "z-score" if diverging else "value"), fontsize=style.axis_font_pt)
        cbar.ax.tick_params(labelsize=style.tick_label_pt)
        # Cluster legend outside.
        from matplotlib.patches import Patch

        handles = [Patch(facecolor=color_map[lab], label=lab) for lab in ordered_labels]
        # Legend ABOVE the heatmap (inside the figure) so it is never clipped on
        # screen — a legend anchored outside the axes only shows up on tight-bbox
        # export, not in the live preview.
        ax.legend(handles=handles, title=(f"{k} clusters" if show_cluster_title else None),
                  loc="lower left", bbox_to_anchor=(0.0, 1.02), frameon=False,
                  ncol=min(len(ordered_labels), 4),
                  fontsize=max(7.5, style.legend_pt - 1), title_fontsize=max(8.0, style.legend_pt),
                  columnspacing=1.2, handlelength=1.2, borderpad=0.2)
        for spine in ax.spines.values():
            spine.set_visible(False)
        fig.tight_layout()

    meta = base_metadata(spec, style, df, used_columns=[row_id or df.columns[0]] + list(value_cols))
    meta["clustered_axis"] = axis
    meta["k"] = k
    meta["scale"] = scale
    meta["distance_metric"] = metric
    meta["linkage_method"] = method
    meta["cluster_summary"] = summary
    meta["cluster_assignment"] = table.to_dict(orient="records")
    return RenderResult(figure=fig, metadata=meta, warnings=warnings)
